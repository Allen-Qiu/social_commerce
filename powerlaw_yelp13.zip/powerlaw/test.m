fileID = fopen('degree-yelp6.txt','r');
formatSpec = '%d';
A = fscanf(fileID,formatSpec);
[alpha, xmin, L]= plfit(A);
h1=plplot(A,xmin,alpha);

%%
fileID = fopen('degree-yelp8.txt','r');
formatSpec = '%d';
A = fscanf(fileID,formatSpec);
[alpha, xmin, L]= plfit(A);
h2=plplot(A,xmin,alpha);
%%
fileID = fopen('degree-yelp11.txt','r');
formatSpec = '%d';
A = fscanf(fileID,formatSpec);
[alpha, xmin, L]= plfit(A);
h3=plplot(A,xmin,alpha);
%%
fileID = fopen('degree-yelp13.txt','r');
formatSpec = '%d';
A = fscanf(fileID,formatSpec);
[alpha, xmin, L]= plfit(A);
h4=plplot(A,xmin,alpha);
